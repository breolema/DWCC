//importamos de funcions.js
import { crearArray,mostrarArray } from './funcions.js';

//mandamos os numeros por parámetro
let num1=4;
let num2=5;
let num3=9;

//chamamos as funcions
crearArray(num1,num2,num3);
mostrarArray();